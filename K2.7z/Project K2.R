## Install
#install.packages("NLP")
#install.packages("tm")  # for text mining
#install.packages("SnowballC") # for text stemming
#install.packages("wordcloud") # word-cloud generator 
#install.packages("RColorBrewer") # color palettes
#install.packages("syuzhet") # for sentiment analysis
#install.packages("ggplot2") # for plotting graphs
#install.packages("stringr")
#install.packages("dplyr")
#install.packages("scales")
#install.packages("lubridate")
#install.packages("quanteda")
#install.packages("readr")
#install.packages("SentimentAnalysis")
#install.packages("tidyverse")
#install.packages("corpustools")
#install.packages("textclean")
#install.packages("tibbletime")
#install.packages("anomalize")
#install.packages("timetk")
## Load
library(NLP)
library(tm)
library(SnowballC)
library(wordcloud)
library(RColorBrewer)
library(syuzhet)
library(ggplot2)
library(stringr)
library(dplyr)
library(scales)
library(lubridate)
library(quanteda)
library(readr)
library(SentimentAnalysis)
library(tidyverse)
library(corpustools)
library(textclean)
library(tibbletime)
library(anomalize)
library(timetk)

library(readxl)
tweets_hashtag_RemovedFirstRow <- read_excel("C:/Users/Karsten/OneDrive/Studium/MAKEathon/tweets_hashtag_RemovedFirstRow.xlsx")
t1 <- tweets_hashtag_RemovedFirstRow

#filter english 
#Useless as file only contains de translated into en
t1En <- filter(t1, t1$lang == 'de')
#t1En <- t1
#Remove Spam from help.ch
#filter(t1En, (str_detect(t1En["content"], "https://t.co/eWFBklmzVk")))


t1EnFiltered <- t1En[!grepl("https://t.co/eWFBklmzVk", t1En$content),]
t1EnFiltered <- t1En[!grepl("https://t.co/3q1s7uBy4R", t1En$content),]
t1EnFiltered2 <- t1EnFiltered[!grepl("help_ch", t1EnFiltered$content),]
t1EnFiltered3 <- t1EnFiltered2[!grepl("Help_ch", t1EnFiltered2$content),]


# Read the text file from local machine , choose file interactively
textEn <- iconv(t1EnFiltered3$`content`, to = "utf-8")
textEn_Outlier <- t1EnFiltered3
textEn_Outlier$date <- as.Date(textEn_Outlier$date)
textEn_Outlier <- filter(textEn_Outlier, textEn_Outlier$date == "2010-12-07")
textEn_Outlier <- iconv(textEn_Outlier$`content`, to = "utf-8")
textDocEn_Outlier <- Corpus(VectorSource(textEn_Outlier))

# Load the data as a corpus
TextDocEn <- Corpus(VectorSource(textEn))


#Replacing "/", "@" and "|" with space
toSpace <- content_transformer(function (x , pattern ) gsub(pattern, " ", x))
TextDocEn <- tm_map(TextDocEn, toSpace, "/")
TextDocEn <- tm_map(TextDocEn, toSpace, "@")
TextDocEn <- tm_map(TextDocEn, toSpace, "\\|")
# Convert the text to lower case
TextDocEn <- tm_map(TextDocEn, content_transformer(tolower))
# Remove numbers
TextDocEn <- tm_map(TextDocEn, removeNumbers)
# Remove english common stopwords
TextDocEn <- tm_map(TextDocEn, removeWords, stopwords("german"))
# Remove punctuations
TextDocEn <- tm_map(TextDocEn, removePunctuation)
# Eliminate extra white spaces
TextDocEn <- tm_map(TextDocEn, stripWhitespace)
# Text stemming - which reduces words to their root form
TextDocEn <- tm_map(TextDocEn, stemDocument)
#Remove Ascii
removeNonAscii <- function(x) textclean:: replace_non_ascii(x)
TextDocEn <- tm_map (TextDocEn, content_transformer (removeNonAscii))
# Remove your own stop word
# specify your custom stopwords as a character vector
TextDocEn <- tm_map(TextDocEn, removeWords, c('amf', 'ufef', 's', 'efeft', 'a', 'yuh', 'tco', 'postfin', 'bank', 'via'))
#TextDocEn <- tm_map(TextDocEn, removeWords, c('Aktuelle Suchabfrage "postfinance" auf @Help_ch #postfinance #Suchportal #Schweiz #Suche https://t.co/eWFBklmzVk'))



removeURL <- function(x) gsub('http[[:alnum:]]*', '', x)
TextDocEn<- tm_map(TextDocEn, content_transformer(removeURL))

#inspect(TextDocEn)

# Build a term-document matrix
TextDoc_dtm <- TermDocumentMatrix(TextDocEn)
dtm_m <- as.matrix(TextDoc_dtm)
# Sort by descearing value of frequency
dtm_v <- sort(rowSums(dtm_m),decreasing=TRUE)
dtm_d <- data.frame(word = names(dtm_v),freq=dtm_v)
# Display the top 5 most frequent words
head(dtm_d, 10)
# Plot the most frequent words
barplot(dtm_d[1:10,]$freq, las = 2, names.arg = dtm_d[1:10,]$word,
        col ="yellow", main ="Top 10 most frequent words",
        ylab = "Word frequencies")
#inspect(TextDocEn)


#generate word cloud
set.seed(1234)
wordcloud(words = dtm_d$word, freq = dtm_d$freq, min.freq = 5,
          max.words=100, random.order=FALSE, rot.per=0.40, 
          colors=brewer.pal(8, "Dark2"))

# Find associations 
findAssocs(TextDoc_dtm, terms = c("gut","innovativ","einfach"), corlimit = 0.25)

# Find associations for words that occur at least 50 times
findAssocs(TextDoc_dtm, terms = findFreqTerms(TextDoc_dtm, lowfreq = 50), corlimit = 0.25)

inspect(TextDoc_dtm)

##Sentiment Scores
## regular sentiment score using get_sentiment() function and method of your choice
## please note that different methods may have different scales
#syuzhet_vector <- get_sentiment(TextDocEn, method="syuzhet")
## see the first row of the vector
#head(syuzhet_vector)
## see summary statistics of the vector
#summary(syuzhet_vector)
#
#simple_plot(TextDocEn, title = "Test")
#
#plot(
#  TextDocEn,
#  type = "1",
#  xlab = "Time",
#  ylab = "Sentiments",
#  main = "Raw Sentiment Values"
#)
#
## bing
#bing_vector <- get_sentiment(TextDocEn, method="bing")
#head(bing_vector)
#summary(bing_vector)
##affin
#afinn_vector <- get_sentiment(TextDocEn, method="afinn")
#head(afinn_vector)
#summary(afinn_vector)
#
##compare the first row of each vector using sign function
#rbind(
#  sign(head(syuzhet_vector)),
#  sign(head(bing_vector)),
#  sign(head(afinn_vector))
#)

# run nrc sentiment analysis to return data frame with each row classified as one of the following
# emotions, rather than a score: 
# anger, anticipation, disgust, fear, joy, sadness, surprise, trust 
# It also counts the number of positive and negative emotions found in each row
d<-get_nrc_sentiment(t1EnFiltered3$content)
# head(d,10) - to see top 10 lines of the get_nrc_sentiment dataframe
head (d,10)

#Sentiment analysis
#transpose
td<-data.frame(t(d))
#The function rowSums computes column sums across rows for each level of a grouping variable.
td_new <- data.frame(rowSums(td[1:2591]))
#Transformation and cleaning
names(td_new)[1] <- "count"
td_new <- cbind("sentiment" = rownames(td_new), td_new)
rownames(td_new) <- NULL
td_new2<-td_new[1:8,]
#Plot One - count of words associated with each sentiment
quickplot(sentiment, data=td_new2, weight=count, geom="bar", fill=sentiment, ylab="count")+ggtitle("Twitter sentiments")

##Plot two - count of words associated with each sentiment, expressed as a percentage
#barplot(
#  sort(colSums(prop.table(d[, 1:8]))), 
#  horiz = TRUE, 
#  cex.names = 0.7, 
#  las = 1, 
#  main = "Emotions in Text", xlab="Percentage"
#)

##Apply anomaly detection and plot the results
#anomalies = AnomalyDetectionTs(t1_anomaly_Count, direction="pos", plot=TRUE)
#anomalies$anoms
##anomalies$plot

df_anomalized <- t1_anomaly_Count %>%
  time_decompose(n, method = "twitter", merge = TRUE) %>%
  anomalize(remainder,  method = "iqr") %>%
  time_recompose()
df_anomalized %>% glimpse()

#Plot
df_anomalized %>% plot_anomalies(ncol = 1, alpha_dots = 0.75)

#Extract points
df_anomalized %>% 
  time_decompose(n) %>%
  anomalize(remainder) %>%
  time_recompose() %>%
  filter(anomaly == 'Yes')

#Sentiment over anomalies

# run nrc sentiment analysis to return data frame with each row classified as one of the following
# emotions, rather than a score: 
# anger, anticipation, disgust, fear, joy, sadness, surprise, trust 
# It also counts the number of positive and negative emotions found in each row
#Change to date
t1EnFiltered3_Outlier <- t1EnFiltered3
t1EnFiltered3_Outlier$date <- as.Date(t1EnFiltered3_Outlier$date)
t1EnFiltered3_Outlier <- filter(t1EnFiltered3_Outlier, t1EnFiltered3_Outlier$date == "2010-12-07")
d_Outlier<-get_nrc_sentiment(t1EnFiltered3_Outlier$content)
# head(d,10) - to see top 10 lines of the get_nrc_sentiment dataframe
#head (d_Outlier,10)

td_Outlier <-data.frame(t(d_Outlier))
#The function rowSums computes column sums across rows for each level of a grouping variable.
td_Outlier_new <- data.frame(rowSums(td_Outlier[1:54]))
#Transformation and cleaning
names(td_Outlier_new)[1] <- "count"
td_Outlier_new <- cbind("sentiment" = rownames(td_Outlier_new), td_Outlier_new)
rownames(td_Outlier_new) <- NULL
td_new2<-td_Outlier_new[1:8,]
#Plot One - count of words associated with each sentiment
quickplot(sentiment, data=td_new2, weight=count, geom="bar", fill=sentiment, ylab="count")+ggtitle("2010-12-07 sentiments")


#Wordcloud


#Replacing "/", "@" and "|" with space
TextDocEn_Outlier <- tm_map(textDocEn_Outlier, toSpace, "/")
TextDocEn_Outlier <- tm_map(TextDocEn_Outlier, toSpace, "@")
TextDocEn_Outlier <- tm_map(TextDocEn_Outlier, toSpace, "\\|")
# Convert the text to lower case
TextDocEn_Outlier <- tm_map(TextDocEn_Outlier, content_transformer(tolower))
# Remove numbers
TextDocEn_Outlier <- tm_map(TextDocEn_Outlier, removeNumbers)
# Remove english common stopwords
TextDocEn_Outlier <- tm_map(TextDocEn_Outlier, removeWords, stopwords("german"))
# Remove punctuations
TextDocEn_Outlier <- tm_map(TextDocEn_Outlier, removePunctuation)
# Eliminate extra white spaces
TextDocEn_Outlier <- tm_map(TextDocEn_Outlier, stripWhitespace)
# Text stemming - which reduces words to their root form
TextDocEn_Outlier <- tm_map(TextDocEn_Outlier, stemDocument)
#Remove Ascii
TextDocEn_Outlier <- tm_map (TextDocEn_Outlier, content_transformer (removeNonAscii))
# Remove your own stop word
# specify your custom stopwords as a character vector
TextDocEn_Outlier <- tm_map(TextDocEn_Outlier, removeWords, c('amf', 'ufef', 's', 'efeft', 'a', 'yuh', 'tco', 'postfin', 'bank', 'via'))
#TextDocEn_Outlier <- tm_map(TextDocEn_Outlier, removeWords, c('Aktuelle Suchabfrage "postfinance" auf @Help_ch #postfinance #Suchportal #Schweiz #Suche https://t.co/eWFBklmzVk'))

TextDocEn_Outlier<- tm_map(TextDocEn_Outlier, content_transformer(removeURL))


# Build a term-document matrix
TextDoc_dtm_Outlier <- TermDocumentMatrix(TextDocEn_Outlier)
dtm_m_Outlier <- as.matrix(TextDoc_dtm_Outlier)
# Sort by descearing value of frequency
dtm_v_Outlier <- sort(rowSums(dtm_m_Outlier),decreasing=TRUE)
dtm_d_Outlier <- data.frame(word = names(dtm_v_Outlier),freq=dtm_v_Outlier)
# Display the top 5 most frequent words
head(dtm_d_Outlier, 10)
# Plot the most frequent words
barplot(dtm_d_Outlier[1:10,]$freq, las = 2, names.arg = dtm_d_Outlier[1:10,]$word,
        col ="yellow", main ="Top 10 most frequent words",
        ylab = "Word frequencies")
#inspect(TextDocEn_Outlier)
#generate word cloud
set.seed(1234)
wordcloud(words = dtm_d_Outlier$word, freq = dtm_d_Outlier$freq, min.freq = 5,
          max.words=20, random.order=FALSE, rot.per=0.40, 
          colors=brewer.pal(8, "Dark2"))


